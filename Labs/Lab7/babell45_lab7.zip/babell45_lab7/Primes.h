using namespace std;
#include <string>

#ifndef PRIMES_H
#define PRIMES_H

void findPrimes(int, int, string);

bool isPrime(int);

#endif //PRIMES_H