#include <iostream>
using namespace std;

#ifndef MOONPIE_H

#define MOONPIE_H

int* makeArray(int);

float enterStolenMoonPies(int*, int);

int highestMoonPies(int*, int);

int lowestMoonPies(int*, int);

int totalMoonPies(int*, int);

float averageMoonPies(int*, int, int);


#endif